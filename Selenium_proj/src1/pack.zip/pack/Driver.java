package pack;

import org.openqa.selenium.WebDriver;

public class Driver {
	public static WebDriver driver;
}
