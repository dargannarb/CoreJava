package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class loginPage {

	public static By userName() {
		return By.id("email");
	}
	
	public static By password() {
		return By.id("pass");
	}

	public static By logInButton() {
		return By.name("login");
	}
	
	
}
