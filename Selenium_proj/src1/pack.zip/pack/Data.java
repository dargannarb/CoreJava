package pack;

import java.util.HashMap;

public class Data {

	public static HashMap<String, String> config;
	public static HashMap<String, String> testData;
}
