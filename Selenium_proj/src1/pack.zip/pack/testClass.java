package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class testClass extends Common{
	@Test(priority = 1)
	public void searchForFrind() throws InterruptedException {
		Events.enterValue(By.xpath("//input[@type='search']"), "Thulasi");
	 Events.clickOnelement(By.xpath("//ul[@aria-label='9 suggested searches']/li[1]//span/span/span[2]"));
	 for(WebElement ele: Events.waitForElements(By.xpath("//span[contains(text(),'Thulasi')]"))) {
		 System.out.println(ele.getText());
		 Assert.assertTrue(ele.getText().contains("Thulasi"), "Thulasi not fount in element text");
	 }
	 System.out.println("All Thulasi related friends are printed");
	}

	@Test(priority = 2)
	public void getCountOfFriends() throws InterruptedException {
		Thread.sleep(5000);
		Driver.driver.findElement(By.xpath("//div[@aria-label='Account controls and settings']//a/span/span/../preceding-sibling::div/div")).click();
		Thread.sleep(5000);
		System.out.println(Driver.driver.findElement(By.xpath("//span[text()='Friends']/span[2]")).getText());
		Assert.assertTrue(Driver.driver.findElement(By.xpath("//span[text()='Friends']/span[2]")).getText().equals("11"),"friends is not equal to 11");
		System.out.println("friends is equal to 11");
	}

	
	
/*	
	@Test
	public void softAssert(){
		SoftAssert softAssertion= new SoftAssert();
		System.out.println("softAssert Method Was Started");
		softAssertion.assertEquals(10, 11);
		System.out.println("softAssert Method Was Executed");
		softAssertion.assertEquals(10, 11,"ijfiekpoedqokpeuirh");
		System.out.println("softAssert Method Was Executed");
		softAssertion.assertEquals(10, 11);
		System.out.println("softAssert Method Was Executed");
		softAssertion.assertAll();
	}
	
	@Test
	public void hardAssert(){
		System.out.println("hardAssert Method Was Started");
		Assert.assertEquals(12, 12);
		System.out.println("hardAssert Method Was Executed");
	}
	*/
}
