package pack;

public class WebDriver_Waits {
/*
	WebDriver waits
	
	1.PageLoadTimeOut (Get()) this is webdriver method     (time,timeunit)
	     webdrive wait untill page gets loads   
	   
	2.ImplicitWait    this is webdriver method
	  webdrive wait untill page all elements gets  load (time,timeunit)
	  
	3.ExplicitWait   this method is from webdriverwait class
		 webdrive wait for particular element  (time,timeunit) //15- 10000  // 200 //50  // 
		 
		  
	
	4 fluent wait    exception 
	   webdrive wait for particular element  (time,timeunit) //10 - 10000  // 200 //50  // it will exception
	
	
	
	*/
}
