package pack;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

public class Utils {
	
	public HashMap<String, String> readDataFromPropFile(String path) throws IOException {
		HashMap<String, String> data = new HashMap<>();
		FileInputStream fis = new FileInputStream(path);
		Properties props = new Properties();
		props.load(fis);
		Set<Object> keys = props.keySet();
		for (Object key : keys) {
		   data.put(key.toString(), props.get(key).toString());
		}
		return data;
	}
	public String[][] readDataFromPropFileToArray(String path) throws IOException {
		String data[][];
		FileInputStream fis = new FileInputStream(path);
		Properties props = new Properties();
		props.load(fis);
		Set<Object> keys = props.keySet();
		data=new String[keys.size()][keys.size()];
		
		
		return data;
	}
	

}
