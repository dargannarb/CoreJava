package pack;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Events {
	static Alert alert;

	public static void clickOnelement(By by) {
		waitForElement(by).click();
	}

	public static void enterValue(By by, String value) {
		waitForElement(by).sendKeys(value);
	}

	public static void acceptAlert() {
		alert = Driver.driver.switchTo().alert();
		alert.accept();
	}

	public static void rejectAlert() {
		alert = Driver.driver.switchTo().alert();
		alert.dismiss();
	}
	
	public static void isDisplayed(By by) {
		if(waitForElement(by).isDisplayed()) {
			System.out.println("logged in successfull");
		}else {
			System.out.println("logged in is not successfull");
			System.exit(0);
		}
	}
	
	public static WebElement waitForElement(By by) {
		WebDriverWait wait=new WebDriverWait(Driver.driver, 20);
		wait.pollingEvery(Duration.ofMillis(100));
		return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	
	public static List<WebElement> waitForElements(By by) {
		WebDriverWait wait=new WebDriverWait(Driver.driver, 20);
		wait.pollingEvery(Duration.ofMillis(200));
		return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
	}
}
